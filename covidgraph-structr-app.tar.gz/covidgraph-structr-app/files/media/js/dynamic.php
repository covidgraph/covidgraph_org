window._site.forumUser = "";
$(document).ready( function () {
	window._site.comments( $('div.content div.comments'), [{"id":"3023","username":"allan","comment":"<p>Anyone looking for the SSP class can <a rel=\"nofollow\" href=\"https:\/\/github.com\/DataTables\/DataTablesSrc\/blob\/master\/examples\/server_side\/scripts\/ssp.class.php\">find it here<\/a> or in the full DataTables <a rel=\"nofollow\" href=\"\/download\/packages\">download package<\/a>.<\/p>\n","created":"17:19, Mon 13th Nov 2017","parent":null,"version":"1.10.16","children":[]}] );
} );window._site.page = "examples\/server_side\/simple.html";

$(document).ready( function () {
	window._site.dynamicLoaded();
} );

window._site.csrfToken = 'cef49db6970b47cace00efef5aba5db9c8bfe2c34d45c5b0';



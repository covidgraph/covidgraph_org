/******************************************************************************\
 * META SCHEMA
 *
 * deleteExisting....delete all existing metaschemata with the given name.
 * infer.............automatically inferes a schema from a given neo4j database.
 *
\******************************************************************************/

const MetaSchema = {
	
	deleteExisting : function(name) {
	
		const existingSchemata = $.find('MetaSchema', {
			name : name
		});

		for(let existingSchema of existingSchemata) {
			let existingNodes = existingSchema.nodes;
			let existingEdges = existingSchema.edges;
			$.delete(existingNodes);
			$.delete(existingEdges);
		}
		
		$.delete(existingSchemata);
	
	},
	
	infer : function(name, credentials) {

		$.log('Credentials: ', JSON.stringify(credentials));
		
		// delete existing Metaschemata with the same name
		//MetaSchema.deleteExisting(name);

		// create NeoConnector
		const connector = $.create('NeoConnector', {
			name     : name,
			url      : credentials.url,
			username : credentials.username,
			password : credentials.password
		});

		$.log('Connector: ', $.to_json(connector));
		
		// create MetaSchema 
		const metaSchema = $.create('MetaSchema', {
			name : name,
			connector : connector
		});
		
		$.log('MetaSchema: ', $.to_json(metaSchema));
		
		// compute all labels, i.e. node types
		/*const labels = connector.query(credentials, 'MATCH (n) RETURN distinct labels(n)');
		for(let label of labels) {
			$.log('Label: ', JSON.stringify(label))
			/*$.create('MetaSchemaNode', {
				name       : label,
				metaschema : metaSchema
			});*/
		//}
		

	}

};